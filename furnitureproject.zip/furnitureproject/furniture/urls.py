from django.contrib import admin
from django.urls import path, include
from furniture import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from .forms import LoginForm, MyPasswordChangeForm, MyPasswordResetForm, MySetPasswordForm

urlpatterns = [
    # path('', views.index, name="home"),
    path('', views.ProductView.as_view(), name='home'),
    path('productDetail/<int:pk>', views.ProductDetailView.as_view(), name='productDetail'),

    path('productList/', views.productList, name='productList'),
    path('productList/<slug:data>', views.productList, name='productListdata'),

    path('sofas/', views.sofas, name='sofas'),
    path('sofas/<slug:data>', views.sofas, name='sofasdata'),

    path('beds/', views.beds, name='beds'),
    path('beds/<slug:data>', views.beds, name='bedsdata'),

    path('fdining/', views.fdining, name='fdining'),
    path('fdining/<slug:data>', views.fdining, name='fdiningdata'),

    path('fchair/', views.fchair, name='fchair'),
    path('fchair/<slug:data>', views.fchair, name='fchairdata'),

    path('ftables/', views.ftables, name='ftables'),
    path('ftables/<slug:data>', views.ftables, name='ftablesdata'),

    path('fcabinetry/', views.fcabinetry, name='fcabinetry'),
    path('fcabinetry/<slug:data>', views.fcabinetry, name='fcabinetrydata'),

    path('fseating/', views.fseating, name='fseating'),
    path('fseating/<slug:data>', views.fseating, name='fseatingdata'),

    path('llighting/', views.llighting, name='llighting'),
    path('llighting/<slug:data>', views.llighting, name='llightingdata'),

    path('lsofas/', views.lsofas, name='lsofas'),
    path('lsofas/<slug:data>', views.lsofas, name='lsofasdata'),

    path('lseating/', views.lseating, name='lseating'),
    path('lseating/<slug:data>', views.lseating, name='lseatingdata'),

    path('lchairs/', views.lchairs, name='lchairs'),
    path('lchairs/<slug:data>', views.lchairs, name='lchairsdata'),

    path('ltables/', views.ltables, name='ltables'),
    path('ltables/<slug:data>', views.ltables, name='ltablesdata'),

    path('lcabinetry/', views.lcabinetry, name='lcabinetry'),
    path('lcabinetry/<slug:data>', views.lcabinetry, name='lcabinetrydata'),

    path('ldecor/', views.ldecor, name='ldecor'),
    path('ldecor/<slug:data>', views.ldecor, name='ldecordata'),

    path('kbeds/', views.kbeds, name='kbeds'),
    path('kbeds/<slug:data>', views.kbeds, name='kbedsdata'),

    path('kstudy/', views.kstudy, name='kstudy'),
    path('kstudy/<slug:data>', views.kstudy, name='kstudydata'),

    path('kstorage/', views.kstorage, name='kstorage'),
    path('kstorage/<slug:data>', views.kstorage, name='kstoragedata'),

    path('kseating/', views.kseating, name='kseating'),
    path('kseating/<slug:data>', views.kseating, name='kseatingdata'),

    path('kdecor/', views.kdecor, name='kdecor'),
    path('kdecor/<slug:data>', views.kdecor, name='kdecordata'),

    path('kbedding/', views.kbedding, name='kbedding'),
    path('kbedding/<slug:data>', views.kbedding, name='kbeddingdata'),

    path('kfurnishings/', views.kfurnishings, name='kfurnishings'),
    path('kfurnishings/<slug:data>', views.kfurnishings, name='kfurnishingsdata'),



    path('fnflooring/', views.fnflooring, name='fnflooring'),
    path('fnflooring/<slug:data>', views.fnflooring, name='fnflooringdata'),
    
    path('fnbed/', views.fnbed, name='fnbed'),
    path('fnbed/<slug:data>', views.fnbed, name='fnbeddata'),
    
    path('fncurtains/', views.fncurtains, name='fncurtains'),
    path('fncurtains/<slug:data>', views.fncurtains, name='fncurtainsdata'),
    
    path('fnbath/', views.fnbath, name='fnbath'),
    path('fnbath/<slug:data>', views.fnbath, name='fnbathdata'),

    path('fntable/', views.fntable, name='fntable'),
    path('fntable/<slug:data>', views.fntable, name='fntabledata'),
    
    path('fncushion/', views.fncushion, name='fncushion'),
    path('fncushion/<slug:data>', views.fncushion, name='fncushiondata'),
    
    path('fnessentials/', views.fnessentials, name='fnessentials'),
    path('fnessentials/<slug:data>', views.fnessentials, name='fnessentialsdata'),
    


    path('dwallart/', views.dwallart, name='dwallart'),
    path('dwallart/<slug:data>', views.dwallart, name='dwallartdata'),
    
    path('dwallaccents/', views.dwallaccents, name='dwallaccents'),
    path('dwallaccents/<slug:data>', views.dwallaccents, name='dwallaccentsdata'),
    
    path('dtable/', views.dtable, name='dtable'),
    path('dtable/<slug:data>', views.dtable, name='dtabledata'),
    
    path('dspiritual/', views.dspiritual, name='dspiritual'),
    path('dspiritual/<slug:data>', views.dspiritual, name='dspiritualdata'),
    
    path('dhomegarden/', views.dhomegarden, name='dhomegarden'),
    path('dhomegarden/<slug:data>', views.dhomegarden, name='dhomegardendata'),

    path('dtableware/', views.dtableware, name='dtableware'),
    path('dtableware/<slug:data>', views.dtableware, name='dtablewaredata'),
    
    path('dhomeservices/', views.dhomeservices, name='dhomeservices'),
    path('dhomeservices/<slug:data>', views.dhomeservices, name='dhomeservicesdata'),
    


    path('lhwalllights/', views.lhwalllights, name='lhwalllights'),
    path('lhwalllights/<slug:data>', views.lhwalllights, name='lhwalllightsdata'),
    
    path('lhlamps/', views.lhlamps, name='lhlamps'),
    path('lhlamps/<slug:data>', views.lhlamps, name='lhlampsdata'),
    
    path('lhceilinglights/', views.lhceilinglights, name='lhceilinglights'),
    path('lhceilinglights/<slug:data>', views.lhceilinglights, name='lhceilinglightsdata'),
    
    path('lhsmartlights/', views.lhsmartlights, name='lhsmartlights'),
    path('lhsmartlights/<slug:data>', views.lhsmartlights, name='lhsmartlightsdata'),
    
    path('lhoutdoorlights/', views.lhoutdoorlights, name='lhoutdoorlights'),
    path('lhoutdoorlights/<slug:data>', views.lhoutdoorlights, name='lhoutdoorlightsdata'),
    
    path('lhfestivelights/', views.lhfestivelights, name='lhfestivelights'),
    path('lhfestivelights/<slug:data>', views.lhfestivelights, name='lhfestivelightsdata'),
    
    path('lhledlights/', views.lhledlights, name='lhledlights'),
    path('lhledlights/<slug:data>', views.lhledlights, name='lhledlightsdata'),
    





    path('contact/', views.contact, name='contact'),

    path('profile/', views.ProfileView.as_view(), name='profile'),

    path('address/', views.address, name='address'),

    # path('userLogin/', views.userLogin, name="userLogin"),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='login.html', authentication_form=LoginForm), name="login"), 

    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    # path('userRegister/', views.userRegister, name="userRegister"),
    path('registration/', views.CustomerRegistrationView.as_view(), name='userRegister'),
    
    path('checkout/', views.checkout, name='checkout'),
    path('paymentdone/', views.payment_done, name='paymentdone'),

    path('orders/', views.orders, name='orders'),

    path('userWishlist/', views.userWishlist, name='userWishlist'),

    path('password-reset/', auth_views.PasswordResetView.as_view(template_name='password_reset.html', form_class=MyPasswordResetForm), name='password_reset'),
    path('password-reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='password_reset_done.html'), name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html', form_class=MySetPasswordForm), name='password_reset_confirm'),
    path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'), name='password_reset_complete'),

    path('passwordchange/', auth_views.PasswordChangeView.as_view(template_name='passwordchange.html', form_class=MyPasswordChangeForm, success_url='/passwordchangedone/'), name='passwordchange'),
    path('passwordchangedone/', auth_views.PasswordChangeDoneView.as_view(template_name='passwordchangedone.html'), name='passwordchangedone'),

    path('aboutUs/', views.aboutUs, name='aboutUs'),
    
    path('add-to-cart/', views.add_to_cart, name='add-to-cart'),
    path('cart/', views.show_cart, name='showcart'),

    path('pluscart/', views.plus_cart),
    path('minuscart/', views.minus_cart),
    path('removecart/', views.remove_cart),


    

    
   
   
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
