from django.db import models

# Create your models here.

# me, start
from django.contrib.auth.models import User 
from django.core.validators import MaxValueValidator, MinValueValidator
STATE_CHOICES = (
    ('Andaman & Nicobar Islands','Andaman & Nicobar Islands'),
    ('Andhra Pradesh','Andhra Pradesh'),
    ('Arunachal Pradesh','Arunachal Pradesh'),
    ('Assam','Assam'),
    ('Bihar','Bihar'),
    ('Chhattisgarh','Chhattisgarh'),
    ('Goa','Goa'),
    ('Gujarat','Gujarat'),
    ('Haryana','Haryana'),
    ('Himachal Pradesh','Himachal Pradesh'),
    ('Jammu and Kashmir','Jammu and Kashmir'),
    ('Jharkhand','Jharkhand'),
    ('Karnataka','Karnataka'),
    ('Kerala','Kerala'),
    ('Madhya Pradesh','Madhya Pradesh'),
    ('Maharashtra','Maharashtra'),
    ('Manipur','Manipur'),
    ('Meghalaya','Meghalaya'),
    ('Mizoram','Mizoram'),
    ('Nagaland','Nagaland'),
    ('Odisha','Odisha'),
    ('Punjab','Punjab'),
    ('Rajasthan','Rajasthan'),
    ('Sikkim','Sikkim'),
    ('Tamil Nadu','Tamil Nadu'),
    ('Telangana','Telangana'),
    ('Tripura','Tripura'),
    ('Uttar Pradesh','Uttar Pradesh'),
    ('Uttarakhand','Uttarakhand'),
    ('West Bengal','West Bengal'),
    ('Andaman and Nicobar Islands','Andaman and Nicobar Islands'),
    ('Chandigarh','Chandigarh'),
    ('Dadra and Nagar Haveli','Dadra and Nagar Haveli'),
    ('Daman and Diu','Daman and Diu'),
    ('Lakshadweep','Lakshadweep'),
    ('National Capital Territory of Delhi','National Capital Territory of Delhi'),
    ('Puducherry','Puducherry'), 
)
# state = models.CharField(choices=state_choices,max_length=255, null=True, blank=True) # me
class Customer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)      
    name = models.CharField(max_length=200)
    phone = models.CharField(max_length=30)      # now me
    email = models.CharField(max_length=100)      # now me
    address = models.CharField(max_length=200)      # now me
    locality = models.CharField(max_length=200)  # locality :-(mean):- ilaka / in:- Area
    city = models.CharField(max_length=80)
    state = models.CharField(choices=STATE_CHOICES, max_length=100)
    country = models.CharField(max_length=100)      # now me
    zipcode = models.IntegerField()
    

    def __str__(self):
        return str(self.id)   
    

CATEGORY_CHOICES = (
    # ('S','Sofa'),       # in Furniture :- Sofas , Add after
    # ('SS','Sofa Sets'),
    # ('SCS','Sectional Sofas'),
    # ('SCB','Sofa Cum Beds'),
    # ('R','Recliners'),
    # ('SPA','Sofa Spa'),
    # ('ST','Settees'),      # in Furniture :- Seating
    # ('B','Benches'),
    # ('CL','Chaise Loungers'),
    # ('RE','Recamiers'),
    # ('O','Ottomans'),
    # ('P','Pouffes'),
    # ('FS','Foot Stools'),
    # ('STS','Seating Stools'),
    # ('BB','Bean Bags'),
    # ('SW','Swings'),
    # ('H','Hammocks'),
    # ('AC','Arm Chairs'),         # in Furniture :- Chairs
    # ('RC','Rocking Chairs'),
    # ('M','Mobile'),
    # ('M','Mobile'),
    # ('M','Mobile'),
    # ('M','Mobile'),

    ('FS','Furniture, Sofas'),   # in Furniture 
    ('FST','Furniture, Seating'),
    ('FC','Furniture, Chairs'),
    ('FT','Furniture, Tables'),
    ('FCB','Furniture, Cabinetry'),
    ('FDB','Furniture, Dining & Bar'),
    ('FB','Furniture, Beds'), 

    ('LS','Living, Sofas'),   # in Living
    ('LST','Living, Seating'),
    ('LC','Living, Chairs'),
    ('LT','Living, Tables'),
    ('LCB','Living, Cabinetry'),
    ('LD','Living, Decor'),
    ('LL','Living, Lighting'),

    ('KB','Kids Room, Beds'),    # in Kids Room
    ('KS','Kids Room, Study'),
    ('KSR','Kids Room, Storage'),
    ('KST','Kids Room, Seating'),
    ('KD','Kids Room, Decor'),
    ('KF','Kids Room, Furnishings'),
    ('KBD','Kids Room, Bedding'),

    ('FNF','Furnishings, Flooring'),  # in Furnishings
    ('FNBL','Furnishings, Bed Linen'),
    ('FNC','Furnishings, Curtains'),
    ('FBAL','Furnishings, Bath Linen'),
    ('FNCC','Furnishings, Cushion & Covers'),
    ('FNTL','Furnishings, Table Linen'),
    ('FNE','Furnishings, Essentials'),

    ('DW','Decor, Wall Accents'),  # in Decor
    ('DWA','Decor, Wall Art'),
    ('DT','Decor, Table Decor'),
    ('DS','Decor, Spiritual'),
    ('DH','Decor, Home Garden'),
    ('DTW','Decor, Tableware'),
    ('DHS','Decor, Home Services'),

    ('LHW','Lighting, Wall Lights'),       # in Lighting
    ('LHL','Lighting, Lamps'),
    ('LHC','Lighting, Ceiling Lights'),
    ('LHS','Lighting, Smart Lights'),
    ('LHO','Lighting, Outdoor Lights'),
    ('LHF','Lighting, Festive Lights'),
    ('LHLL','Lighting, LED Lights'),

    ('M','Mobile'),
    ('L','Laptop'),
    ('TW','Top Wear'),
    ('BW','Bottom Wear'),
)
class Product(models.Model):
    title = models.CharField(max_length=100)
    selling_price = models.FloatField()
    discounted_price = models.FloatField()
    description = models.TextField()
    brand = models.CharField(max_length=100)
    category = models.CharField(choices=CATEGORY_CHOICES, max_length=8)
    product_image = models.ImageField(upload_to='productimg')
    def __str__(self):
        return str(self.id)   
   

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)  
    def __str__(self):
        return str(self.id)  

    @property
    def total_cost(self):
        return self.quantity * self.product.discounted_price
        
   

STATUS_CHOICES = (
    ('Accepted','Accepted'),
    ('Packed','Packed'),
    ('On The Way','On The Way'),
    ('Delivered','Delivered'),
    ('Cancle','Cancle'),
)
class OrderPlaced(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    ordered_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50,choices=STATUS_CHOICES,default='Pending')

    @property
    def total_cost(self):
        return self.quantity * self.product.discounted_price
      
    