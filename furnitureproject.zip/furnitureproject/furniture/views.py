from django.shortcuts import render, redirect
from django.views import View
from .models import Customer, Product, Cart, OrderPlaced  
from .forms import CustomerRegistrationForm, CustomerProfileForm
from django.contrib import messages
from django.db.models import Q
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

#  superuser = admin , password = admin                  /vid.1 = time 2:36:25  /vid.2 = 02:07:00
#  username = devendra , password = Dev905775@                                  / me,seen, User check & pending:- 02:07:00 to 02:15:00
                                                                                # after work, registrations form pending:-02:28:00, & 02:55:30
# Create your views here.                                                       / 05:16:00 error ,in product minimum price
                                                                                # 06:13:00
# def index(request):                                                           / paypal start 
#     return render(request, 'index.html')                                       #  1:38:00 kuch nahi, agar sabhi page par data upload no ho to ,nhi huaa
                                                                                # how to built in registram form in add mobile number
class ProductView(View):                                                        # ab page benana hai
    def get(self, request):
        FurnitureSofas = Product.objects.filter(category='FS')
        FurnitureSeating = Product.objects.filter(category='FST')
        FurnitureChairs = Product.objects.filter(category='FC')
        FurnitureTables = Product.objects.filter(category='FT')
        FurnitureCabinetry = Product.objects.filter(category='FCB')
        FurnitureDiningBar = Product.objects.filter(category='FDB')
        FurnitureBeds = Product.objects.filter(category='FB')

        LivingSofas = Product.objects.filter(category='LS')
        LivingSeating = Product.objects.filter(category='LST')
        LivingChairs = Product.objects.filter(category='LC')
        LivingTables = Product.objects.filter(category='LT')
        LivingCabinetry = Product.objects.filter(category='LCB')
        LivingDecor = Product.objects.filter(category='LD')
        LivingLighting = Product.objects.filter(category='LL')

        KidsRoomBeds = Product.objects.filter(category='KB')
        KidsRoomStudy = Product.objects.filter(category='KS')
        KidsRoomStorage = Product.objects.filter(category='KSR')
        KidsRoomSeating = Product.objects.filter(category='KST')
        KidsRoomDecor = Product.objects.filter(category='KD')
        KidsRoomFurnishings = Product.objects.filter(category='KF')
        KidsRoomBedding = Product.objects.filter(category='KBD')

        FurnishingsFlooring = Product.objects.filter(category='FNF')
        FurnishingsBedLinen = Product.objects.filter(category='FNBL')
        FurnishingsCurtains = Product.objects.filter(category='FNC')
        FurnishingsBathLinen = Product.objects.filter(category='FNBA')
        FurnishingsCushionCovers = Product.objects.filter(category='FNCC')
        FurnishingsTableLinen = Product.objects.filter(category='FNTL')
        FurnishingsEssentials = Product.objects.filter(category='FNE')

        DecorWallAccents = Product.objects.filter(category='DW')
        DecorWallArt = Product.objects.filter(category='DWA')
        DecorTableDecor = Product.objects.filter(category='DT')
        DecorSpiritual = Product.objects.filter(category='DS')
        DecorHomeGarden = Product.objects.filter(category='DH')
        DecorTableware = Product.objects.filter(category='DTW')
        DecorHomeServices = Product.objects.filter(category='DHS')

        LightingWallLights = Product.objects.filter(category='LHW')
        LightingLamps = Product.objects.filter(category='LHL')
        LightingCeilingLights = Product.objects.filter(category='LHC')
        LightingSmartLights = Product.objects.filter(category='LHS')
        LightingOutdoorLights = Product.objects.filter(category='LHO')
        LightingFestiveLights = Product.objects.filter(category='LHF')
        LightingLEDLights = Product.objects.filter(category='LHLL')

        topwears = Product.objects.filter(category='TW')
        bottomwears = Product.objects.filter(category='BW')
        mobiles = Product.objects.filter(category='M')
        return render(request, 'index.html', { 
            'FurnitureSofas':FurnitureSofas, 'FurnitureSeating':FurnitureSeating, 'FurnitureChairs':FurnitureChairs, 'FurnitureTables':FurnitureTables, 'FurnitureCabinetry':FurnitureCabinetry, 'FurnitureDiningBar':FurnitureDiningBar, 'FurnitureBeds':FurnitureBeds,
            'LivingSofas':LivingSofas, 'LivingSeating':LivingSeating, 'LivingChairs':LivingChairs, 'LivingTables':LivingTables, 'LivingCabinetry':LivingCabinetry, 'LivingDecor':LivingDecor, 'LivingLighting':LivingLighting,
            'KidsRoomBeds':KidsRoomBeds, 'KidsRoomStudy':KidsRoomStudy, 'KidsRoomStorage':KidsRoomStorage, 'KidsRoomSeating':KidsRoomSeating, 'KidsRoomDecor':KidsRoomDecor, 'KidsRoomFurnishings':KidsRoomFurnishings, 'KidsRoomBedding':KidsRoomBedding,
            'FurnishingsFlooring':FurnishingsFlooring, 'FurnishingsBedLinen':FurnishingsBedLinen, 'FurnishingsCurtains':FurnishingsCurtains, 'FurnishingsBathLinen':FurnishingsBathLinen, 'FurnishingsCushionCovers':FurnishingsCushionCovers, 'FurnishingsTableLinen':FurnishingsTableLinen, 'FurnishingsEssentials':FurnishingsEssentials,
            'DecorWallAccents':DecorWallAccents, 'DecorWallArt':DecorWallArt, 'DecorTableDecor':DecorTableDecor, 'DecorSpiritual':DecorSpiritual, 'DecorHomeGarden':DecorHomeGarden, 'DecorTableware':DecorTableware, 'DecorHomeServices':DecorHomeServices,
            'LightingWallLights':LightingWallLights, 'LightingLamps':LightingLamps, 'LightingCeilingLights':LightingCeilingLights, 'LightingSmartLights':LightingSmartLights, 'LightingOutdoorLights':LightingOutdoorLights, 'LightingFestiveLights':LightingFestiveLights, 'LightingLEDLights':LightingLEDLights,
         
            'topwears':topwears, 'bottomwears':bottomwears, 'mobiles':mobiles
        })

# def productDetail(request):
#     return render(request, 'productDetail.html')

class ProductDetailView(View):
    def get(self, request, pk):
        product = Product.objects.get(pk=pk)
        item_already_in_cart = False
        if request.user.is_authenticated:
            item_already_in_cart = Cart.objects.filter(Q(product=product.id) & Q(user=request.user)).exists()
        return render(request, 'productDetail.html', {'product':product, 'item_already_in_cart':item_already_in_cart})
    

def productList(request, data=None):  # me check data and after delete
    if data == None:
        mobiles = Product.objects.filter(category='M')
    elif data == 'Redmi' or data == 'Samsung':
        mobiles = Product.objects.filter(category='M').filter(brand=data)        # pending
    elif data == 'below':
        mobiles = Product.objects.filter(category='FS').filter(discounted_price__lt=30000)  # pending
    elif data == 'above':
        mobiles = Product.objects.filter(category='FS').filter(discounted_price__gt=30000)  # pending
    return render(request, 'productList.html', {'mobiles':mobiles})


def sofas(request, data=None):
    if data == None:
        FurnitureSofas = Product.objects.filter(category='FS')
    elif data == 'sofa' or data == 'Tables':
        FurnitureSofas = Product.objects.filter(category='FS').filter(brand=data)                   # pending
    # elif data == 'below':
    #     FurnitureSofas = Product.objects.filter(category='FS').filter(discounted_price__lt=30000)  # pending
    # elif data == 'above':
    #     FurnitureSofas = Product.objects.filter(category='FS').filter(discounted_price__gt=30000)  # pending
    return render(request, 'sofas.html', {'FurnitureSofas':FurnitureSofas})

def beds(request, data=None):
    if data == None:
        FurnitureBeds = Product.objects.filter(category='FB')
    elif data == 'sofa' or data == 'Tables':
        FurnitureBeds = Product.objects.filter(category='FB').filter(brand=data)                   # pending
    return render(request, 'beds.html', {'FurnitureBeds':FurnitureBeds})

def fdining(request, data=None):
    if data == None:
        FurnitureDiningBar = Product.objects.filter(category='FDB')
    elif data == 'sofa' or data == 'Tables':
        FurnitureDiningBar = Product.objects.filter(category='FDB').filter(brand=data)                   # pending
    return render(request, 'fdining.html', {'FurnitureDiningBar':FurnitureDiningBar})

def fchair(request, data=None):
    if data == None:
        FurnitureChairs = Product.objects.filter(category='FC')
    elif data == 'sofa' or data == 'Tables':
        FurnitureChairs = Product.objects.filter(category='FC').filter(brand=data)                   # pending
    return render(request, 'fchair.html', {'FurnitureChairs':FurnitureChairs})

def ftables(request, data=None):
    if data == None:
        FurnitureTables = Product.objects.filter(category='FT')
    elif data == 'sofa' or data == 'Tables':
        FurnitureTables = Product.objects.filter(category='FT').filter(brand=data)                   # pending
    return render(request, 'ftables.html', {'FurnitureTables':FurnitureTables})

def fcabinetry(request, data=None):
    if data == None:
        FurnitureCabinetry = Product.objects.filter(category='FCB')
    elif data == 'sofa' or data == 'Tables':
        FurnitureCabinetry = Product.objects.filter(category='FCB').filter(brand=data)                   # pending
    return render(request, 'fcabinetry.html', {'FurnitureCabinetry':FurnitureCabinetry})

def fseating(request, data=None):
    if data == None:
        FurnitureSeating = Product.objects.filter(category='FST')
    elif data == 'sofa' or data == 'Tables':
        FurnitureSeating = Product.objects.filter(category='FST').filter(brand=data)                   # pending
    return render(request, 'fseating.html', {'FurnitureSeating':FurnitureSeating})

def llighting(request, data=None):
    if data == None:
        LivingLighting = Product.objects.filter(category='LL')
    elif data == 'sofa' or data == 'Tables':
        LivingLighting = Product.objects.filter(category='LL').filter(brand=data)                   # pending
    return render(request, 'llighting.html', {'LivingLighting':LivingLighting})

def lsofas(request, data=None):
    if data == None:
        LivingSofas = Product.objects.filter(category='LS')
    elif data == 'sofa' or data == 'Tables':
        LivingSofas = Product.objects.filter(category='LS').filter(brand=data)                   # pending
    return render(request, 'lsofas.html', {'LivingSofas':LivingSofas})

def lseating(request, data=None):
    if data == None:
        LivingSeating = Product.objects.filter(category='LST')
    elif data == 'sofa' or data == 'Tables':
        LivingSeating = Product.objects.filter(category='LST').filter(brand=data)                   # pending
    return render(request, 'lseating.html', {'LivingSeating':LivingSeating})

def lchairs(request, data=None):
    if data == None:
        LivingChairs = Product.objects.filter(category='LC')
    elif data == 'sofa' or data == 'Tables':
        LivingChairs = Product.objects.filter(category='LC').filter(brand=data)                   # pending
    return render(request, 'lchairs.html', {'LivingChairs':LivingChairs})

def ltables(request, data=None):
    if data == None:
        LivingTables = Product.objects.filter(category='LT')
    elif data == 'sofa' or data == 'Tables':
        LivingTables = Product.objects.filter(category='LT').filter(brand=data)                   # pending
    return render(request, 'ltables.html', {'LivingTables':LivingTables})

def lcabinetry(request, data=None):
    if data == None:
        LivingCabinetry = Product.objects.filter(category='LCB')
    elif data == 'sofa' or data == 'Tables':
        LivingCabinetry = Product.objects.filter(category='LCB').filter(brand=data)                   # pending
    return render(request, 'lcabinetry.html', {'LivingCabinetry':LivingCabinetry})

def ldecor(request, data=None):
    if data == None:
        LivingDecor = Product.objects.filter(category='LD')
    elif data == 'sofa' or data == 'Tables':
        LivingDecor = Product.objects.filter(category='LD').filter(brand=data)                   # pending
    return render(request, 'ldecor.html', {'LivingDecor':LivingDecor})

def kbeds(request, data=None):
    if data == None:
        KidsRoomBeds = Product.objects.filter(category='KB')
    elif data == 'sofa' or data == 'Tables':
        KidsRoomBeds = Product.objects.filter(category='KB').filter(brand=data)                   # pending
    return render(request, 'kbeds.html', {'KidsRoomBeds':KidsRoomBeds})
    
def kstudy(request, data=None):
    if data == None:
        KidsRoomStudy = Product.objects.filter(category='KS')
    elif data == 'sofa' or data == 'Tables':
        KidsRoomStudy = Product.objects.filter(category='KS').filter(brand=data)                   # pending
    return render(request, 'kstudy.html', {'KidsRoomStudy':KidsRoomStudy})
    
def kstorage(request, data=None):
    if data == None:
        KidsRoomStorage = Product.objects.filter(category='KSR')
    elif data == 'sofa' or data == 'Tables':
        KidsRoomStorage = Product.objects.filter(category='KSR').filter(brand=data)                   # pending
    return render(request, 'kstorage.html', {'KidsRoomStorage':KidsRoomStorage})
    
def kseating(request, data=None):
    if data == None:
        KidsRoomSeating = Product.objects.filter(category='KST')
    elif data == 'sofa' or data == 'Tables':
        KidsRoomSeating = Product.objects.filter(category='KST').filter(brand=data)                   # pending
    return render(request, 'kseating.html', {'KidsRoomSeating':KidsRoomSeating})
    
def kdecor(request, data=None):
    if data == None:
        KidsRoomDecor = Product.objects.filter(category='KD')
    elif data == 'sofa' or data == 'Tables':
        KidsRoomDecor = Product.objects.filter(category='KD').filter(brand=data)                   # pending
    return render(request, 'kdecor.html', {'KidsRoomDecor':KidsRoomDecor})
    
def kbedding(request, data=None):
    if data == None:
        KidsRoomBedding = Product.objects.filter(category='KBD')
    elif data == 'sofa' or data == 'Tables':
        KidsRoomBedding = Product.objects.filter(category='KBD').filter(brand=data)                   # pending
    return render(request, 'kbedding.html', {'KidsRoomBedding':KidsRoomBedding})
    
def kfurnishings(request, data=None):
    if data == None:
        KidsRoomFurnishings = Product.objects.filter(category='KF')
    elif data == 'sofa' or data == 'Tables':
        KidsRoomFurnishings = Product.objects.filter(category='KF').filter(brand=data)                   # pending
    return render(request, 'kfurnishings.html', {'KidsRoomFurnishings':KidsRoomFurnishings})
    



def fnflooring(request, data=None):
    if data == None:
        FurnishingsFlooring = Product.objects.filter(category='FNF')
    elif data == 'sofa' or data == 'Tables':
        FurnishingsFlooring = Product.objects.filter(category='FNF').filter(brand=data)                   # pending
    return render(request, 'fnflooring.html', {'FurnishingsFlooring':FurnishingsFlooring})
    
def fnbed(request, data=None):
    if data == None:
        FurnishingsBedLinen = Product.objects.filter(category='FNBL')
    elif data == 'sofa' or data == 'Tables':
        FurnishingsBedLinen = Product.objects.filter(category='FNBL').filter(brand=data)                   # pending
    return render(request, 'fnbed.html', {'FurnishingsBedLinen':FurnishingsBedLinen})
    
def fncurtains(request, data=None):
    if data == None:
        FurnishingsCurtains = Product.objects.filter(category='FNC')
    elif data == 'sofa' or data == 'Tables':
        FurnishingsCurtains = Product.objects.filter(category='FNC').filter(brand=data)                   # pending
    return render(request, 'fncurtains.html', {'FurnishingsCurtains':FurnishingsCurtains})
    
def fnbath(request, data=None):
    if data == None:
        FurnishingsBathLinen = Product.objects.filter(category='FNBA')
    elif data == 'sofa' or data == 'Tables':
        FurnishingsBathLinen = Product.objects.filter(category='FNBA').filter(brand=data)                   # pending
    return render(request, 'fnbath.html', {'FurnishingsBathLinen':FurnishingsBathLinen})
    
def fntable(request, data=None):
    if data == None:
        FurnishingsTableLinen = Product.objects.filter(category='FNTL')
    elif data == 'sofa' or data == 'Tables':
        FurnishingsTableLinen = Product.objects.filter(category='FNTL').filter(brand=data)                   # pending
    return render(request, 'fntable.html', {'FurnishingsTableLinen':FurnishingsTableLinen})
    
def fncushion(request, data=None):
    if data == None:
        FurnishingsCushionCovers = Product.objects.filter(category='FNCC')
    elif data == 'sofa' or data == 'Tables':
        FurnishingsCushionCovers = Product.objects.filter(category='FNCC').filter(brand=data)                   # pending
    return render(request, 'fncushion.html', {'FurnishingsCushionCovers':FurnishingsCushionCovers})
    
def fnessentials(request, data=None):
    if data == None:
        FurnishingsEssentials = Product.objects.filter(category='FNE')
    elif data == 'sofa' or data == 'Tables':
        FurnishingsEssentials = Product.objects.filter(category='FNE').filter(brand=data)                   # pending
    return render(request, 'fnessentials.html', {'FurnishingsEssentials':FurnishingsEssentials})
    



def dwallart(request, data=None):
    if data == None:
        DecorWallArt = Product.objects.filter(category='DWA')
    elif data == 'sofa' or data == 'Tables':
        DecorWallArt = Product.objects.filter(category='DWA').filter(brand=data)                   # pending
    return render(request, 'dwallart.html', {'DecorWallArt':DecorWallArt})
    
def dwallaccents(request, data=None):
    if data == None:
        DecorWallAccents = Product.objects.filter(category='DW')
    elif data == 'sofa' or data == 'Tables':
        DecorWallAccents = Product.objects.filter(category='DW').filter(brand=data)                   # pending
    return render(request, 'dwallaccents.html', {'DecorWallAccents':DecorWallAccents})
    
def dtable(request, data=None):
    if data == None:
        DecorTableDecor = Product.objects.filter(category='DT')
    elif data == 'sofa' or data == 'Tables':
        DecorTableDecor = Product.objects.filter(category='DT').filter(brand=data)                   # pending
    return render(request, 'dtable.html', {'DecorTableDecor':DecorTableDecor})
    
def dspiritual(request, data=None):
    if data == None:
        DecorSpiritual = Product.objects.filter(category='DS')
    elif data == 'sofa' or data == 'Tables':
        DecorSpiritual = Product.objects.filter(category='DS').filter(brand=data)                   # pending
    return render(request, 'dspiritual.html', {'DecorSpiritual':DecorSpiritual})
    
def dhomegarden(request, data=None):
    if data == None:
        DecorHomeGarden = Product.objects.filter(category='DH')
    elif data == 'sofa' or data == 'Tables':
        DecorHomeGarden = Product.objects.filter(category='DH').filter(brand=data)                   # pending
    return render(request, 'dhomegarden.html', {'DecorHomeGarden':DecorHomeGarden})
    
def dtableware(request, data=None):
    if data == None:
        DecorTableware = Product.objects.filter(category='DTW')
    elif data == 'sofa' or data == 'Tables':
        DecorTableware = Product.objects.filter(category='DTW').filter(brand=data)                   # pending
    return render(request, 'dtableware.html', {'DecorTableware':DecorTableware})
    
def dhomeservices(request, data=None):
    if data == None:
        DecorHomeServices = Product.objects.filter(category='DHS')
    elif data == 'sofa' or data == 'Tables':
        DecorHomeServices = Product.objects.filter(category='DHS').filter(brand=data)                   # pending
    return render(request, 'dhomeservices.html', {'DecorHomeServices':DecorHomeServices})
    



def lhwalllights(request, data=None):
    if data == None:
        LightingWallLights = Product.objects.filter(category='LHW')
    elif data == 'sofa' or data == 'Tables':
        LightingWallLights = Product.objects.filter(category='LHW').filter(brand=data)                   # pending
    return render(request, 'lhwalllights.html', {'LightingWallLights':LightingWallLights})
    
def lhlamps(request, data=None):
    if data == None:
        LightingLamps = Product.objects.filter(category='LHL')
    elif data == 'sofa' or data == 'Tables':
        LightingLamps = Product.objects.filter(category='LHL').filter(brand=data)                   # pending
    return render(request, 'lhlamps.html', {'LightingLamps':LightingLamps})
    
def lhceilinglights(request, data=None):
    if data == None:
        LightingCeilingLights = Product.objects.filter(category='LHC')
    elif data == 'sofa' or data == 'Tables':
        LightingCeilingLights = Product.objects.filter(category='LHC').filter(brand=data)                   # pending
    return render(request, 'lhceilinglights.html', {'LightingCeilingLights':LightingCeilingLights})
    
def lhsmartlights(request, data=None):
    if data == None:
        LightingSmartLights = Product.objects.filter(category='LHS')
    elif data == 'sofa' or data == 'Tables':
        LightingSmartLights = Product.objects.filter(category='LHS').filter(brand=data)                   # pending
    return render(request, 'lhsmartlights.html', {'LightingSmartLights':LightingSmartLights})
    
def lhoutdoorlights(request, data=None):
    if data == None:
        LightingOutdoorLights = Product.objects.filter(category='LHO')
    elif data == 'sofa' or data == 'Tables':
        LightingOutdoorLights = Product.objects.filter(category='LHO').filter(brand=data)                   # pending
    return render(request, 'lhoutdoorlights.html', {'LightingOutdoorLights':LightingOutdoorLights})
    
def lhfestivelights(request, data=None):
    if data == None:
        LightingFestiveLights = Product.objects.filter(category='LHF')
    elif data == 'sofa' or data == 'Tables':
        LightingFestiveLights = Product.objects.filter(category='LHF').filter(brand=data)                   # pending
    return render(request, 'lhfestivelights.html', {'LightingFestiveLights':LightingFestiveLights})
    
def lhledlights(request, data=None):
    if data == None:
        LightingLEDLights = Product.objects.filter(category='LHLL')
    elif data == 'sofa' or data == 'Tables':
        LightingLEDLights = Product.objects.filter(category='LHLL').filter(brand=data)                   # pending
    return render(request, 'lhledlights.html', {'LightingLEDLights':LightingLEDLights})
    






def contact(request):
    return render(request, 'contact.html')

def userAccount(request):
    return render(request, 'userAccount.html')

# def userLogin(request):
#     return render(request, 'userLogin.html')

# def userRegister(request):
#     return render(request, 'userRegister.html')

class CustomerRegistrationView(View):
    def get(self, request):
        form = CustomerRegistrationForm()
        return render(request, 'userRegister.html', {'form':form})
    def post(self, request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, 'Congratulations!! Registered Successfully !')
            form.save()
        return render(request, 'userRegister.html', {'form':form})

@login_required
def checkout(request):
    user = request.user
    add = Customer.objects.filter(user=user)
    cart_items = Cart.objects.filter(user=user)
    amount = 0.0
    shipping_amount = 70.0
    totalamount = 0.0
    cart_product = [p for p in Cart.objects.all() if p.user ==request.user] 
    if cart_product:
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
        totalamount = amount + shipping_amount
    return render(request, 'checkout.html', {'add':add, 'totalamount':totalamount, 'cart_items':cart_items})

@login_required
def payment_done(request):
    user = request.user
    custid = request.GET.get('custid')
    customer = Customer.objects.get(id=custid)
    cart = Cart.objects.filter(user=user)
    for c in cart:
        OrderPlaced(user=user, customer=customer, product=c.product, quantity=c.quantity).save()
        c.delete()
    return redirect("orders")

def userWishlist(request):
    return render(request, 'userWishlist.html')

def aboutUs(request):
    return render(request, 'aboutUs.html')

@login_required
def address(request):
    add = Customer.objects.filter(user=request.user)
    return render(request, 'address.html', {'add':add, 'active':'btn-primary'})
    

@method_decorator(login_required, name='dispatch')
class ProfileView(View):
    def get(self, request):
        form = CustomerProfileForm()
        return render(request, 'profile.html', {'form':form, 'active':'btn-primary'})

    def post(self, request):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            usr = request.user
            name = form.cleaned_data['name']
            phone = form.cleaned_data['phone']
            email = form.cleaned_data['email']
            address = form.cleaned_data['address']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            state = form.cleaned_data['state']
            country = form.cleaned_data['country']
            zipcode = form.cleaned_data['zipcode']
            reg = Customer(user=usr, name=name, phone=phone, email=email, address=address, locality=locality, city=city, state=state, country=country, zipcode=zipcode)
            reg.save()
            messages.success(request, 'Congratulations!! Profile Updated Successfully')
        return render(request, 'profile.html', {'form':form, 'active':'btn-primary'})


@login_required       
def add_to_cart(request):
    user = request.user
    product_id = request.GET.get('prod_id')
    product = Product.objects.get(id=product_id)
    Cart(user=user, product=product).save()
    return redirect('/cart')

@login_required
def show_cart(request):
    if request.user.is_authenticated:
        user = request.user
        cart = Cart.objects.filter(user=user)
        amount = 0.0
        shipping_amount = 70.0
        total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == user] 
        # print(cart_product)
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.product.discounted_price)
                amount += tempamount
                totalamount = amount + shipping_amount
            return render(request, 'addtocart.html', {'carts':cart, 'totalamount':totalamount, 'amount':amount})
        else:
            return render(request, 'emptycart.html')
    
def plus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.quantity+=1
        c.save()
        amount = 0.0
        shipping_amount = 70.0
        cart_product = [p for p in Cart.objects.all() if p.user ==request.user] 
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
            # totalamount = amount + shipping_amount

        data = {
            'quantity': c.quantity,
            'amount': amount,
            'totalamount': amount + shipping_amount,
            }
        return JsonResponse(data)

def minus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.quantity-=1
        c.save()
        amount = 0.0
        shipping_amount = 70.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user] 
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
            # totalamount = amount + shipping_amount

        data = {
            'quantity': c.quantity,
            'amount':amount,
            'totalamount':amount + shipping_amount,
            }
        return JsonResponse(data)

def remove_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.delete()
        amount = 0.0
        shipping_amount = 70.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user] 
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
            # totalamount = amount + shipping_amount

        data = {
            'amount':amount,
            'totalamount':amount + shipping_amount,
            }
        return JsonResponse(data)

    
@login_required
def orders(request):
    op = OrderPlaced.objects.filter(user=request.user)
    return render(request, 'orders.html', {'order_placed':op})
    